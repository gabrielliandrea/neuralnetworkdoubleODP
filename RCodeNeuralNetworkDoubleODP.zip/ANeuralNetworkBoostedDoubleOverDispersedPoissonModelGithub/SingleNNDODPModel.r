#################################
### Single NNDODP Model       ###
### Author: Andrea Gabrielli  ###
### Date: 11.10.2019          ###
#################################


###################################################
### Load the required packages and source files ###
###################################################

library(parallel)
library(foreach)
library(doParallel)
library(data.table)
library(plyr)
library(MASS)
library(keras)
# Important: Set working directory to source file location
source(file="./SimulationMachine/Functions.V1.R")


#########################################
### Generate data for a selected seed ###
#########################################

path1 <- getwd()
setwd(paste(path1,"/SimulationMachine",sep=""))
std1 <- 0.85
std2 <- 0.85
seed.choice <- 75

### Claims of LoBs 1,2,4,5
V <- 1000000                           
LoB.dist <- c(0.25,0.25,0.25,0.25)    
inflation <- c(0.01,0.01,0.01,0.01)   
features <- Feature.Generation(V = V, LoB.dist = LoB.dist, inflation = inflation, seed1 = seed.choice)

f1 <- features[which(features$LoB %in% c("1", "4")),]
out1 <- Simulation.Machine(features = f1, npb = nrow(f1), seed1 = seed.choice, std1 = std1, std2 = std2)
out1$LoB <- c(1,4)[as.numeric(out1$LoB)]

f2 <- features[which(features$LoB %in% c("2", "3")),]
f2$LoB <- as.factor(c(1,1,4)[as.numeric(f2$LoB)])
out2 <- Simulation.Machine(features = f2, npb = nrow(f2), seed1 = seed.choice, std1 = std1, std2 = std2)
out2$LoB <- c(2,5)[as.numeric(out2$LoB)]
output <- rbind(out1, out2)

### Claims of LoBs 3,6
V <- 200000                           
LoB.dist <- c(0.50,0,0,0.50)    
inflation <- c(0.05,0,0,0.05)   
features <- Feature.Generation(V = V, LoB.dist = LoB.dist, inflation = inflation, seed1 = seed.choice)

out3 <- Simulation.Machine(features = features, npb = nrow(features), seed1 = seed.choice, std1 = std1, std2 = std2)
out3$LoB <- c(3,6)[as.numeric(out3$LoB)]
output <- rbind(output, out3)

### Calculate aggregated data in rectangle form
data1 <- ddply(output, .(LoB, AY), summarise,
                RepDel00=sum(RepDel==0), RepDel01=sum(RepDel==1), RepDel02=sum(RepDel==2), RepDel03=sum(RepDel==3), RepDel04=sum(RepDel==4), RepDel05=sum(RepDel==5), RepDel06=sum(RepDel==6), RepDel07=sum(RepDel==7), RepDel08=sum(RepDel==8), RepDel09=sum(RepDel==9), RepDel10=sum(RepDel==10), RepDel11=sum(RepDel==11),
                Pay00=sum(Pay00),Pay01=sum(Pay01),Pay02=sum(Pay02),Pay03=sum(Pay03),Pay04=sum(Pay04),Pay05=sum(Pay05),Pay06=sum(Pay06),Pay07=sum(Pay07),Pay08=sum(Pay08),Pay09=sum(Pay09),Pay10=sum(Pay10),Pay11=sum(Pay11))
data2.1 <- melt(data1[,1:14], id=c("LoB", "AY"))
data2.2 <- melt(data1[,c(1,2,15:26)], id=c("LoB", "AY"))
data2 <- cbind(data2.1,data2.2[,4])
names(data2)[3:5] <- c("DY", "claims", "paid")
data2$DY <- as.numeric(substr(data2$DY, start=7, stop=8))
data2$paid <- data2$paid
dat.all <- data2
setwd(path1)




#########################################################
### Calculate the ccODP values for the neural network ###
#########################################################

LoB <- 1  # LoB is in {1,2,3,4,5,6}
dat.LoB <- dat.all[which(dat.all$LoB==LoB),]
dat.upper <- dat.LoB[which(dat.LoB$AY+dat.LoB$DY<=2005),]
dat.upper$AY <- as.factor(dat.upper$AY)
dat.upper$DY <- as.factor(dat.upper$DY)
ODP.N.0 <- glm(claims ~ AY + DY, data=dat.upper[,c(1:3,4)], family=quasipoisson())
ODP.Y.0 <- glm(paid ~ AY + DY, data=dat.upper[,c(1:3,5)], family=quasipoisson())
alpha.N.0 <- c(0,ODP.N.0$coefficients[2:12])
beta.N.0 <- c(0,ODP.N.0$coefficients[13:23])
intercept.N.0 <- ODP.N.0$coefficients[1]
phi.N <- ODP.N.0$deviance/ODP.N.0$df.residual
alpha.Y.0 <- c(0,ODP.Y.0$coefficients[2:12])
beta.Y.0 <- c(0,ODP.Y.0$coefficients[13:23])
intercept.Y.0 <- ODP.Y.0$coefficients[1]
phi.Y <- ODP.Y.0$deviance/ODP.Y.0$df.residual

##############################################################
### Features and responses for training the neural network ###
##############################################################

dat.LoB <- dat.all[which(dat.all$LoB==LoB),]
dat.upper <- dat.LoB[which(dat.LoB$AY+dat.LoB$DY<=2005),]
dat.upper$AY <- dat.upper$AY-1994
x.upper = list(AccYear = dat.upper$AY, DevYear = dat.upper$DY)
y.upper = list(response_N = dat.upper$claims/phi.N, response_Y = dat.upper$paid/phi.Y)


#######################################################
### Matrix needed to permute the claim counts layer ###
#######################################################

permutation.matrix <- array(NA,12*12*12)
permutation.matrix[1:144] <- c(diag(1,12)[,1],rep(0,11*12))
for (i in 1:11){
  permutation.matrix[i*144+1:144] <- c(diag(1,12)[,i+1],permutation.matrix[(i-1)*144+1:132])
}
permutation.matrix <- matrix(permutation.matrix,nrow=12*12)
permutation.matrix <- t(permutation.matrix)

#################################
### Set the random Keras seed ###
#################################

set.seed(100)
seed1 <- sample(1:1000000, 1)
#k_clear_session()
use_session_with_seed(seed1)


############################
### Neural network model ###
############################

AccYear <- layer_input(shape = c(1), dtype = 'int32', name = 'AccYear')

DevYear <- layer_input(shape = c(1), dtype = 'int32', name = 'DevYear')

AY_embed_N <- AccYear %>% 
  layer_embedding(input_dim = 12, output_dim = 1, trainable=FALSE, input_length = 1,
                  weights=list(array(alpha.N.0, dim=c(12,1)))) %>%
  layer_flatten

AY_embed_Y <- AccYear %>% 
  layer_embedding(input_dim = 12, output_dim = 1, trainable=FALSE, input_length = 1,
                  weights=list(array(alpha.Y.0, dim=c(12,1)))) %>%
  layer_flatten

DY_embed_N <- DevYear %>% 
  layer_embedding(input_dim = 12, output_dim = 1, trainable=FALSE, input_length = 1,
                  weights=list(array(beta.N.0, dim=c(12,1)))) %>%
  layer_flatten

DY_embed_Y <- DevYear %>% 
  layer_embedding(input_dim = 12, output_dim = 1, trainable=FALSE, input_length = 1,
                  weights=list(array(beta.Y.0, dim=c(12,1)))) %>%
  layer_flatten

hidden <- list(AY_embed_N, AY_embed_Y, DY_embed_N, DY_embed_Y) %>%
  layer_concatenate %>% 
  layer_dense(units=30, activation='tanh', kernel_regularizer = regularizer_l2(l = 0.001)) %>%
  layer_dropout(0.2) %>%
  layer_dense(units=25, activation='tanh', kernel_regularizer = regularizer_l2(l = 0.001))

hidden_N0 <- hidden %>%
  layer_dropout(0.2) %>%
  layer_dense(units = 12, activation = 'linear',
              weights = list(array(0,dim=c(25,12)),array(0,12)), kernel_regularizer = regularizer_l2(l = 0.001))

DY_embed_N_skip <- DevYear %>% 
  layer_embedding(input_dim = 12, output_dim = 12, trainable=FALSE, input_length = 1,
                  weights=list(array(rep(beta.N.0,each=12), dim=c(12,12)))) %>%
  layer_flatten

add_N0 <- list(AY_embed_N, DY_embed_N_skip) %>%
  layer_concatenate %>%
  layer_dense(units = 12, activation='linear', trainable = FALSE, 
              weights = list(rbind(rep(1,12),diag(1,12)),array(rep(intercept.N.0-log(phi.N),12))))

hidden_N1 <- list(hidden_N0, add_N0) %>%
  layer_add %>%
  layer_dense(units = 12, activation = 'exponential', trainable = FALSE,
              weights = list(diag(1,12),array(rep(0,12))))

concate_N0 <- list(hidden_N1, hidden_N1, hidden_N1, hidden_N1, hidden_N1, hidden_N1,
                   hidden_N1, hidden_N1, hidden_N1, hidden_N1, hidden_N1, hidden_N1) %>%
  layer_concatenate

DY_embed_permutation_N <- DevYear %>% 
  layer_embedding(input_dim = 12, output_dim = 12*12, trainable=FALSE, input_length = 1,
                  weights=list(permutation.matrix)) %>%
  layer_flatten

hidden_N2 <- list(concate_N0, DY_embed_permutation_N) %>%
  layer_multiply %>%
  layer_dense(units = 12, activation = 'linear', trainable = FALSE,
              weights = list(matrix(rep(diag(1,12),each=12),nrow=12*12),array(rep(0,12))))

response_N <- hidden_N2 %>%
  layer_dense(units = 1, activation='linear', trainable = FALSE,
              weights = list(array(diag(1,12)[,1],dim=c(12,1)),array(0,dim=c(1))), name = 'response_N')

hidden_N3 <- hidden_N2 %>%
  layer_batch_normalization()

hidden2 <- list(AY_embed_N, AY_embed_Y, DY_embed_N, DY_embed_Y) %>%
  layer_concatenate %>%
  layer_dense(units=30, activation='tanh', kernel_regularizer = regularizer_l2(l = 0.001)) %>%
  layer_dropout(0.2) %>%
  layer_dense(units=25, activation='tanh', kernel_regularizer = regularizer_l2(l = 0.001)) %>%
  layer_dropout(0.2) %>%
  layer_dense(units=12, activation='linear', kernel_regularizer = regularizer_l2(l = 0.001),
              weights = list(array(0,dim=c(25,12)),array(rep(1,12))))

hidden_N4 <- list(hidden_N3, hidden2) %>%
  layer_multiply %>%
  layer_dense(units=12, activation='linear', trainable = FALSE,
              weights = list(array(diag(1,12),dim=c(12,12)),array(rep(0,12))))

hidden_Y <- list(hidden, hidden_N4) %>%
  layer_concatenate %>%
  layer_dropout(0.2) %>%
  layer_dense(units = 1, activation = 'linear',
              weights = list(array(0,dim=c(25+12,1)),array(0,dim=c(1))), kernel_regularizer = regularizer_l2(l = 0.001))

add_Y0 <- list(AY_embed_Y, DY_embed_Y) %>%
  layer_concatenate %>%
  layer_dense(units = 1, activation = 'linear', trainable = FALSE,
              weights = list(array(1,dim=c(2,1)),array(-log(phi.Y),dim=c(1))))

response_Y <- list(add_Y0, hidden_Y) %>%
  layer_add %>%
  layer_dense(units = 1, activation = 'exponential', trainable = FALSE,
              weights = list(array(1,dim=c(1,1)),array(intercept.Y.0,dim=c(1))), name = 'response_Y')

model <- keras_model(inputs = c(AccYear, DevYear), outputs = c(response_N, response_Y))
model %>% compile(optimizer = optimizer_rmsprop(), loss = list(response_N = 'poisson', response_Y = 'poisson'), loss_weights = list(response_N = 1, response_Y = 1))


################################
### Train the neural network ###
################################

epochs <- 390
epochs.cont <- 20 # for averaging

### Train the neural network
model %>% fit(x = x.upper, y = y.upper, epochs = epochs, batch_size = length(x.upper[[1]]), verbose = 0)

### Store the weights of the model
model %>% save_model_weights_hdf5("./SingleNNDODPModelWeights/weights.00.hdf5")

### Prepare callback (for the next 20 iterations we will store the weights)
filepath <- file.path("./SingleNNDODPModelWeights/weights.{epoch:02d}.hdf5")

### Create checkpoint callback
cp.callback <- callback_model_checkpoint(
  filepath = filepath,
  save_weights_only = TRUE,
  verbose = 0
)

### Fit the model (for the additional 20 epochs)
model %>% fit(x = x.upper, y = y.upper, epochs = epochs.cont, batch_size = length(x.upper[[1]]), verbose = 0, callbacks = list(cp.callback))

####################################################################################################
### Calculation of the single NNDODP outstanding number of claims and the single NNDODP reserves ###
####################################################################################################

### Features of the lower triangle
dat.lower <- dat.LoB[which(dat.LoB$AY+dat.LoB$DY>2005),]
dat.lower$AY <- dat.lower$AY-1994
x.lower = list(AccYear = dat.lower$AY, DevYear = dat.lower$DY)

### Initialize the quantities we will store
reserves.N <- 0
reserves.Y <- 0

### Store the results for the chosen 21 epochs
for (e in 0:epochs.cont){
  
  ### Load the model weights
  e.count <- sprintf("%02d",e)
  load_model_weights_hdf5(model,paste("./SingleNNDODPModelWeights/weights.",e.count,".hdf5",sep=""))
  
  ### Prediction of the number of claims and of the payments in the lower triangle
  dat.lower$claimspred <- as.vector((model %>% predict(x.lower))[[1]])*phi.N
  dat.lower$paidpred <- as.vector((model %>% predict(x.lower))[[2]])*phi.Y
  
  ### Outstanding number of claims and reserves
  dat.lower$claimspred <- round(dat.lower$claimspred)
  dat.lower$paidpred <- round(dat.lower$paidpred)
  reserves.N <- reserves.N + sum(dat.lower$claimspred)
  reserves.Y <- reserves.Y + sum(dat.lower$paidpred)
}

### Results
round((single.NNDODP.outstanding.number.of.claims <- reserves.N/(epochs.cont+1)))
round((single.NNDODP.reserves <- reserves.Y/(epochs.cont+1))/1000)
